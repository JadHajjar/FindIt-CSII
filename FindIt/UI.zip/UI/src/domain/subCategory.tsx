export interface PrefabSubCategory {
  id: number;
  icon: string;
  toolTip: string;
}
