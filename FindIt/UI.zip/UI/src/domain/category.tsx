export interface PrefabCategory {
  id: number;
  icon: string;
  toolTip: string;
}
